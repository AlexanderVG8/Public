# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy

class Product(scrapy.Item):
    """ Данные спаршенные о конкретном продукте. """

    _INTEGERS = ["price", "views", "likes"]

    def __init__(self, **kwargs):
        """ Распознаем цифровые поля из строк. """
        
        if "есплатно" in kwargs.get("price"):
            kwargs["price"] = 0
        
        for key in self._INTEGERS:
            if kwargs.get(key) != None:
                kwargs[key] = int(kwargs[key])
        
        super(Product, self).__init__(**kwargs)

    # Поля

    url = scrapy.Field()
    
    price = scrapy.Field()
    description = scrapy.Field()
    views = scrapy.Field()
    likes = scrapy.Field()

    image_urls = scrapy.Field()
