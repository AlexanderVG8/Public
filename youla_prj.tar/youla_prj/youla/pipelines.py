# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


import scrapy
#from scrapy.exceptions import DropItem

import os
from urllib.parse import quote, urlparse
from datetime import datetime
from os.path import join
from pathlib import Path

# ---

def gen_today_dir():
    """ Хелпер. Папка на текущую дату. """

    date_string  = datetime.today().strftime('%d.%m.%Y')
    today_dir = Path("./exists").joinpath(date_string)
    os.makedirs(today_dir, exist_ok=True)

    return today_dir

# ---

class FilterPipeline:
    """ Проверяем подходит ли товар под ограничения на количество лайков и просмотров. """

    def process_item(self, item, spider):

        s = spider.settings

        # %TODO
        if item.get('likes') == None :
            return item

        if not (
            s["FILTER_MIN_VIEWS"] <= item["views"] and
            item["views"] <= s["FILTER_MAX_VIEWS"] and
            s["FILTER_MIN_LIKES"] <= item["likes"] and
            item["likes"] <= s["FILTER_MAX_LIKES"]):
            return None
            #raise DropItem("Не подходит по лайко-просмотрам")
        else:
            return item

# ---

from twisted.internet.defer import DeferredList 

import pprint
pp = pprint.PrettyPrinter(indent=4)


class MainYoulaPipeline:
    """ Основной пайплайн, загружающий фотографии и рассовывающий их по папкам. """

    def open_spider(self, spider):
        """ Сначала упорядочиваем скрейпы по дате. """

        self.today_dir = gen_today_dir()

    def process_item(self, item, spider):

        # Достаем части УРЛ
        path = urlparse(item["url"]).path.strip("/").split("/")
        # Удаляем первый блок пути - там регион поиска
        path = self.today_dir.joinpath(*path[1:])

        # Создаем папку дата/категория/товар
        os.makedirs(path, exist_ok=True)

        # Проверяем, не качали ли уже это объявление
        if (path / "description.json").exists():
            return None
            #raise DropItem("Это объявление уже качали.")

        # Ставим качаться все картинки асинхронно

        engine = spider.crawler.engine # Движок кравлера, где спрятан Twisted

        downloads = [ engine.download(scrapy.Request(url), spider) 
            for url in item['image_urls'] ]
        dlist = DeferredList(downloads).addBoth(
            self.item_completed, item=item, path=path, logger = spider.logger)

        return dlist


    def item_completed(self, result, item, path, logger):
        """ Картинки, похоже, загрузились. """

        # Сохраняем в папку прогруженные картинки

        for (good, response) in result:
            if good:
                file_name = urlparse(response.url).path.split("/")[-1]
                (path / file_name).open("wb").write(response.body)
            else:
                logger.ERROR("Ошибка при загрузке изображения %s" % file_name)

        # Кладем в папку JSON описание товара

        (path / "description.json").open("w").write(pp.pformat({
            "price": item["price"],
            "description": item["description"]
        }))
        
        return item

# ---

from scrapy.exporters import CsvItemExporter

class SummaryPipeline:
    """ CSV таблица пройденных продуктов """

    FIELDS = ["url", "views", "likes", "price"]

    def open_spider(self, spider):
        self.file = open((gen_today_dir() / "export.csv"), "wb")
        self.csv = CsvItemExporter(self.file, fields_to_export = self.FIELDS)
        self.csv.start_exporting()

    def process_item(self, item, spider):
        self.csv.export_item(item)
        return item

    def close_spider(self, spider):
        self.csv.finish_exporting()
        self.file.close()
