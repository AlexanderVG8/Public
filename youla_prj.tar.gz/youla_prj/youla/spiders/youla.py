# -*- coding: utf-8 -*-
import scrapy

from scrapy.http import Request
from scrapy.loader import ItemLoader

from urllib.parse import urljoin

from youla.items import Product

class YoulaSpider(scrapy.Spider):

    name = "youla"

    def start_requests(self):
        return map(scrapy.Request, self.settings["URLS_TO_PARSE"])
        
    def parse(self, response):
        """ Парсер страницы с перечнем товаров. """

        # Парсим ссылку на следущую страницу
        #%TODO: Возможно парсер AJAX дает больше результатов

        link = response.selector.css(
            "a._paginator_next_button::attr('href')").extract_first()

        if not (link == None):
            yield Request(link, meta={'list': True})

        # Парсим ссылки на товары

        links = response.selector.css(
            "li.product_item>a::attr('href')").extract()

        yield from (Request(response.urljoin(link), callback=self.parse_item) for link in links)

    def parse_item(self, response):
        """ Парсер страницы с товаром. """

        sel = response.selector

        def big_resolution_url(link):
            """ Вместо ссылки на маленькую картинку получить большую. """
            return link.replace("160_160", "720_720")

        return Product(**{
            "url": response.url,
            "price": sel.css(".product__price::text").extract_first().replace(" ", ""), # %TODO: Пробелы
            "description": sel.css(".product__text::text").extract_first(),
            "views": sel.css(".product__desc>li:nth-child(1)::text").re_first("(\d+)\xa0просмотр"),
            "likes": sel.css(".product__desc>li:nth-child(2)::text").re_first("(\d+) добавили в избранное"),
            "image_urls": 
                [big_resolution_url(link) for link in
                 sel.css(".product__images img").xpath("@src").extract()],
        })