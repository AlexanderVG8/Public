# -*- coding: utf-8 -*-

# Страницы, которые будем парсить
URLS_TO_PARSE = ["https://youla.io/moskva/zhenskaya-odezhda/aksessuary?timeLimit=week"]

# ---

# Фильтр по минимальному-максимальному количеству просмотров
FILTER_MIN_VIEWS = 0
FILTER_MAX_VIEWS = 9999

# Фильтр по минимальному-максимальному количеству лайков
FILTER_MIN_LIKES = 0
FILTER_MAX_LIKES = 9999

# ---

# Здесь можно прописать какой-нибудь "http://127.0.0.1:3128"
HTTP_PROXY = None
HTTPS_PROXY = None

# ---


# Пауза между запросами
DOWNLOAD_DELAY = 0 
# Вносить случайные поправки в паузу
RANDOMIZE_DOWNLOAD_DELAY = False


LOG_FILE = "log.txt" # Файл лога

USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36.'

# Кэшировать все скачанные страницы?

#HTTPCACHE_ENABLED = False
#HTTPCACHE_EXPIRATION_SECS = 0

#HTTPCACHE_DIR = 'httpcache'
#HTTPCACHE_STORAGE = 'scrapy.extensions.httpcache.FilesystemCacheStorage'

### Всякие детали реализации ###

LOG_LEVEL = "INFO"

BOT_NAME = 'youla'

SPIDER_MODULES = ['youla.spiders']
NEWSPIDER_MODULE = 'youla.spiders'

# ---

ITEM_PIPELINES = {
    'youla.pipelines.FilterPipeline': 100,
    'youla.pipelines.MainYoulaPipeline': 300,
    'youla.pipelines.SummaryPipeline': 800,
}

import os

if HTTP_PROXY:
    os.environ["http_proxy"] = HTTP_PROXY
if HTTPS_PROXY:
    os.environ["https_proxy"] = HTTPS_PROXY