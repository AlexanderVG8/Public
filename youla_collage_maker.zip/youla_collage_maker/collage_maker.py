from pathlib import Path
import sys
from PIL import Image, ImageDraw
from progressbar import ProgressBar

# Настройки

SIZE = (1080, 607)
MAIN_WIDTH = 870
HEIGHT = SIZE[1]
SIDEBAR_WIDTH = SIZE[0]-MAIN_WIDTH

PADDING = 10
ROUNDING = 10 # Радиус закругления мелких изображений

# Константы

WHITE = (255, 255, 255)
pbar = ProgressBar()

# Загружаем подпись, и делаем ей маску

watermark = Image.open('watermark.png')
#watermask = watermark.convert("L").point(lambda x: 0 if x >= 225 else 255)

# Код

def extend_image(image, box_size=None):
    """ Добавляем к изображению белого, что-бы оно стало заданного размера,
    или стало квадратным, если размер не указан. """
    
    if box_size is None:
        # Делаем квадрат по наибольшей имеющейся стороне
        assert image.size[0] <= 720 and image.size[1] <= 720
        max_side = max(*image.size)
        box_size = (max_side, max_side)

    image.thumbnail(box_size)

    if image.size == box_size:
        return image
    
    new_image = Image.new('RGB', box_size, WHITE)
    new_image.paste(image,
        [(box_size[i]-image.size[i]) // 2 for i in range(2)])
        
    return new_image

def add_corners(im, rad):
    """ Добавить изображению закругленные углы, с радиусом rad.
        Украл со StackOverflow. """

    circle = Image.new('L', (rad * 2, rad * 2), 0)
    draw = ImageDraw.Draw(circle)
    draw.ellipse((0, 0, rad * 2, rad * 2), fill=255)
    alpha = Image.new('L', im.size, "white")
    w, h = im.size
    alpha.paste(circle.crop((0, 0, rad, rad)), (0, 0))
    alpha.paste(circle.crop((0, rad, rad, rad * 2)), (0, h - rad))
    alpha.paste(circle.crop((rad, 0, rad * 2, rad)), (w - rad, 0))
    alpha.paste(circle.crop((rad, rad, rad * 2, rad * 2)), (w - rad, h - rad))
    im.putalpha(alpha)
    return im

def crop_main_image(image):
    """ Обрезать высоту основного (большого) изображения. """

    H_COORD = (image.height - HEIGHT)//2
    return extend_image(
        image.crop((0, H_COORD, image.width, H_COORD+HEIGHT)), 
        (MAIN_WIDTH, HEIGHT))

def create_collage(images):
    """ Создать коллаж из списка изображений. """

    images = list(images)
    main_image = images[0]

    collage = Image.new('RGB', SIZE, WHITE)
    collage.paste(crop_main_image(main_image))


    # Если же изображений много, лепим их всех справа

    if len(images[1:]) > 0:
        side = min(
            SIDEBAR_WIDTH - 2*PADDING,
            HEIGHT//len(images[1:]) - 2*PADDING)
        size = (side, side)
        for (i, image) in enumerate(images[1:]):
            image.thumbnail(size) # Или thumbnail?
            collage.paste(
                image, 
                (MAIN_WIDTH + PADDING, PADDING + i*(side+2*PADDING)),
                add_corners(image, ROUNDING))

    # Прикладываем надпись в левом нижнем углу
    place = [collage.size[i] - watermark.size[i] for i in range(2)]
    collage.paste(watermark, place, watermark)

    return collage

if __name__ == "__main__":

    main_folder = sys.argv[1] if len(sys.argv) > 1 else "in"

    for folder in pbar(list(Path(main_folder).glob("*"))):
        # Перебираем папки с исходными картинками
        images = [ Image.open(str(path)) for path in 
            list(folder.glob("*.jpg"))[:5] ]
        if len(images) == 0:
            print("\nПапка %s пустая!" % str(folder))
            continue
        collage = create_collage(images)
        folder_name = folder.parts[-1]
        collage.save(str(Path("out") / (folder_name + ".jpg")), "JPEG")